# a94f9198-ba4c-4b58-8767-8dee653b1070-159692eb-e721-4d80-b2c5-a33b3226292e
Repository for Teams Project code and project management
