package com.examly.springapp.controller;

import com.examly.springapp.model.AdminUser;
import com.examly.springapp.service.AdminUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin")
public class AdminUserController {

    @Autowired
    private AdminUserService adminUserService;

    @PostMapping("/create")
    public ResponseEntity<AdminUser> addAdmin(@RequestBody AdminUser adminUser) {
        AdminUser savedAdmin = adminUserService.saveAdminUser(adminUser);
        return ResponseEntity.ok(savedAdmin);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdminUser> getAdminById(@PathVariable Long id) {
        Optional<AdminUser> admin = adminUserService.getAdminUserById(id);
        return admin.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<AdminUser> updateAdmin(@PathVariable Long id, @RequestBody AdminUser adminUser) {
        AdminUser updatedAdmin = adminUserService.updateAdminUser(id, adminUser);
        return ResponseEntity.ok(updatedAdmin);
    }

    @GetMapping
    public ResponseEntity<List<AdminUser>> getAllAdmins() {
        List<AdminUser> admins = adminUserService.getAllAdminUsers();
        return ResponseEntity.ok(admins);
    }
}
