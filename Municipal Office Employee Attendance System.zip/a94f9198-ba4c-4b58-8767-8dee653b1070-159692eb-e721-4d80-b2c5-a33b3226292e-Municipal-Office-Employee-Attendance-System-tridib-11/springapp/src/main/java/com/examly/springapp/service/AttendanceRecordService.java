package com.examly.springapp.service;

import com.examly.springapp.model.AttendanceRecord;
import java.util.List;
import java.util.Optional;

public interface AttendanceRecordService {
    AttendanceRecord saveAttendanceRecord(AttendanceRecord attendanceRecord);
    Optional<AttendanceRecord> getAttendanceRecordById(Long id);
    AttendanceRecord updateAttendanceRecord(Long id, AttendanceRecord attendanceRecord);
    List<AttendanceRecord> getAllAttendanceRecords();
}