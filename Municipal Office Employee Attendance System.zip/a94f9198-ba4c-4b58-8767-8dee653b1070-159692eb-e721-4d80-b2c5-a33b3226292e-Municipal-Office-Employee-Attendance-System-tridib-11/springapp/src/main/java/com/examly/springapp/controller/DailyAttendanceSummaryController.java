package com.examly.springapp.controller;

import com.examly.springapp.model.DailyAttendanceSummary;
import com.examly.springapp.service.DailyAttendanceSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/daily-summary")
public class DailyAttendanceSummaryController {

    @Autowired
    private DailyAttendanceSummaryService dailyAttendanceSummaryService;

    @PostMapping("/create")
    public ResponseEntity<DailyAttendanceSummary> createSummary(@RequestBody DailyAttendanceSummary summary) {
        DailyAttendanceSummary savedSummary = dailyAttendanceSummaryService.saveDailyAttendanceSummary(summary);
        return ResponseEntity.ok(savedSummary);
    }

    @GetMapping("/employee/{id}")
    public ResponseEntity<Page<DailyAttendanceSummary>> getSummaryByEmployeeId(
            @PathVariable Long id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<DailyAttendanceSummary> summaries = dailyAttendanceSummaryService.getSummaryByEmployeeId(id, pageable);
        return ResponseEntity.ok(summaries);
    }

    @GetMapping("/employee/code/{empCode}")
    public ResponseEntity<Page<DailyAttendanceSummary>> getSummaryByEmployeeCodeAndDateRange(
            @PathVariable String empCode,
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);
        Pageable pageable = PageRequest.of(page, size);
        
        Page<DailyAttendanceSummary> summaries = dailyAttendanceSummaryService
            .getSummaryByEmployeeCodeAndDateRange(empCode, start, end, pageable);
        return ResponseEntity.ok(summaries);
    }
}
