package com.examly.springapp.controller;

import com.examly.springapp.model.AttendanceLog;
import com.examly.springapp.service.AttendanceLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/attendancelogs")
public class AttendanceLogController {

    @Autowired
    private AttendanceLogService attendanceLogService;

    @PostMapping
    public ResponseEntity<AttendanceLog> addAttendanceLog(@RequestBody AttendanceLog attendanceLog) {
        AttendanceLog savedLog = attendanceLogService.saveAttendanceLog(attendanceLog);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedLog);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AttendanceLog> updateAttendanceLog(@PathVariable Long id, @RequestBody AttendanceLog attendanceLog) {
        AttendanceLog updatedLog = attendanceLogService.updateAttendanceLog(id, attendanceLog);
        return ResponseEntity.ok(updatedLog);
    }

    @GetMapping
    public ResponseEntity<List<AttendanceLog>> getAllAttendanceLogs() {
        List<AttendanceLog> logs = attendanceLogService.getAllAttendanceLogs();
        return ResponseEntity.ok(logs);
    }
}
