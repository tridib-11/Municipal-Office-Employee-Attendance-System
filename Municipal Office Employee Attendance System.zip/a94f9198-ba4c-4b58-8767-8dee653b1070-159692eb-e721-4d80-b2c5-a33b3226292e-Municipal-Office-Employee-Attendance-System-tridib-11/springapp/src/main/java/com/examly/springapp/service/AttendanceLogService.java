package com.examly.springapp.service;

import com.examly.springapp.model.AttendanceLog;
import java.util.List;
import java.util.Optional;

public interface AttendanceLogService {
    AttendanceLog saveAttendanceLog(AttendanceLog attendanceLog);
    Optional<AttendanceLog> getAttendanceLogById(Long id);
    AttendanceLog updateAttendanceLog(Long id, AttendanceLog attendanceLog);
    List<AttendanceLog> getAllAttendanceLogs();
}