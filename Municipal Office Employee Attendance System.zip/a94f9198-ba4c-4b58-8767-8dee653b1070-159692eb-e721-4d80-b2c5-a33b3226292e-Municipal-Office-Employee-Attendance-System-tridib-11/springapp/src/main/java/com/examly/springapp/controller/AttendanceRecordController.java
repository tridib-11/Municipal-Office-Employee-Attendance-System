package com.examly.springapp.controller;

import com.examly.springapp.model.AttendanceRecord;
import com.examly.springapp.service.AttendanceRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/attendance-records")
public class AttendanceRecordController {

    @Autowired
    private AttendanceRecordService attendanceRecordService;

    @PostMapping
    public ResponseEntity<AttendanceRecord> addAttendanceRecord(@RequestBody AttendanceRecord attendanceRecord) {
        AttendanceRecord savedRecord = attendanceRecordService.saveAttendanceRecord(attendanceRecord);
        return ResponseEntity.ok(savedRecord);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AttendanceRecord> getAttendanceRecordById(@PathVariable Long id) {
        Optional<AttendanceRecord> record = attendanceRecordService.getAttendanceRecordById(id);
        return record.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<AttendanceRecord> updateAttendanceRecord(@PathVariable Long id, @RequestBody AttendanceRecord attendanceRecord) {
        AttendanceRecord updatedRecord = attendanceRecordService.updateAttendanceRecord(id, attendanceRecord);
        return ResponseEntity.ok(updatedRecord);
    }

    @GetMapping
    public ResponseEntity<List<AttendanceRecord>> getAllAttendanceRecords() {
        List<AttendanceRecord> records = attendanceRecordService.getAllAttendanceRecords();
        return ResponseEntity.ok(records);
    }
}
