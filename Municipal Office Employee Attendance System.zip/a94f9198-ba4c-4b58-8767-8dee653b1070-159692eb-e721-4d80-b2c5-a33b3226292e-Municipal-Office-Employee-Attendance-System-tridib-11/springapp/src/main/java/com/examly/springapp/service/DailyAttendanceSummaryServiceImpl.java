package com.examly.springapp.service;

import com.examly.springapp.model.DailyAttendanceSummary;
import com.examly.springapp.repository.DailyAttendanceSummaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;

@Service
public class DailyAttendanceSummaryServiceImpl implements DailyAttendanceSummaryService {

    @Autowired
    private DailyAttendanceSummaryRepository dailyAttendanceSummaryRepository;

    @Override
    public DailyAttendanceSummary saveDailyAttendanceSummary(DailyAttendanceSummary summary) {
        return dailyAttendanceSummaryRepository.save(summary);
    }

    @Override
    public Page<DailyAttendanceSummary> getSummaryByEmployeeId(Long employeeId, Pageable pageable) {
        // For simplicity, return empty page with proper pagination structure
        return new PageImpl<>(new ArrayList<>(), pageable, 0);
    }

    @Override
    public Page<DailyAttendanceSummary> getSummaryByEmployeeCodeAndDateRange(String empCode, LocalDate startDate, LocalDate endDate, Pageable pageable) {
        return dailyAttendanceSummaryRepository.findByEmployeeCodeAndDateBetween(empCode, startDate, endDate, pageable);
    }
}