package com.examly.springapp.service;

import com.examly.springapp.model.AdminUser;
import java.util.List;
import java.util.Optional;

public interface AdminUserService {
    AdminUser saveAdminUser(AdminUser adminUser);
    Optional<AdminUser> getAdminUserById(Long id);
    AdminUser updateAdminUser(Long id, AdminUser adminUser);
    List<AdminUser> getAllAdminUsers();
}